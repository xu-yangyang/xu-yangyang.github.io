% An example of nonnegative Tucker decomposition
%% Generate synthetic 3-order tensor
clear; close all;
Nway = [50,50,50]; % dimension of tensor
coreNway = [5,5,5]; % dimension of core tensor

% randomly generate core tensor
G = max(0,randn(coreNway));
G = tensor(G);
A = cell(1,ndims(G));
% randomly generate factor matrices
for i = 1:ndims(G)
    A{i} = max(0,randn(Nway(i),coreNway(i)));
end
% generate tensor
Mtrue = full(ttensor(G,A)); 
Mtrue = tensor(Mtrue.data/max(Mtrue.data(:)));
N = ndims(Mtrue);

sn = 60; % signal to noise ratio
% -- add noise --
Noise = tensor(max(0,randn(Nway)));
M = Mtrue + 10^(-sn/20)*norm(Mtrue)/norm(Noise)*Noise;

for i = 1:3
    A0{i} = max(0,randn(Nway(i),coreNway(i)));
end

C0 = tensor(max(0,randn(coreNway)));


%% Solve problem
opts = [];
opts.maxit = 1000; opts.tol = 1e-4;
opts.A0 = A0; opts.C0 = C0;
opts.hosvd = 1;
t0 = tic;
[A1,C1,Out1] = ntds_apg(M,coreNway,opts);
time = toc(t0);

% Reporting
relerr = norm(full(ttensor(C1,A1))-Mtrue)/norm(Mtrue);
fprintf('APG: time = %4.2e, ',time);
fprintf('solution relative error = %4.2e\n\n',relerr);
%%
opts = [];
opts.maxit = 1000; opts.tol = 1e-4;
opts.A0 = A0; opts.C0 = C0;
opts.hosvd = 1;
t0 = tic;
[A2,C2,Out2] = ntds_fapg(M,coreNway,opts);
time = toc(t0);

% Reporting
relerr = norm(full(ttensor(C2,A2))-Mtrue)/norm(Mtrue);
fprintf('Improved APG: time = %4.2e, ',time);
fprintf('solution relative error = %4.2e\n\n',relerr);

%%
fig = figure('Papersize',[5,4],'Paperposition',[0,0,5,4]);
semilogy(Out1.hist_rel(2,:),'r--','linewidth',2)
hold on;
semilogy(Out2.hist_rel(2,:),'k-','linewidth',2)
legend('APG','Improved APG','location','northeast');
xlabel('Iterations','fontsize',12)
ylabel('Relative Error','fontsize',12)