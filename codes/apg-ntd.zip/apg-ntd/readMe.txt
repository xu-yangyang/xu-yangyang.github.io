First download the tensor toolbox from
http://www.sandia.gov/~tgkolda/TensorToolbox/

Add all files in your directory. 

Then run

quicktest_ntds: test of sparse nonnegative Tucker decomposition

quicktest_ntdc: test of sparse nonnegative Tucker decomposition with missing values