% An example of nonnegative Tucker decomposition fro partial observations
%% Generate synthetic 3-order tensor
clear; close all;
Nway = [50,50,50]; % dimension of tensor
coreNway = [5,5,5]; % dimension of core tensor

% randomly generate core tensor
G = tensor(max(0,randn(coreNway)));
A = cell(1,ndims(G));
% randomly generate factor matrices
for i = 1:ndims(G)
    A{i} = max(0,randn(Nway(i),coreNway(i)));
end
% generate tensor
M = full(ttensor(G,A)); 
M = tensor(M.data/max(M.data(:)));
N = ndims(M);

sr = 0.5; p = round(sr*prod(Nway));
known = randsample(prod(Nway),p); data = M.data(known);

estM = zeros(Nway);
estM(known) = data;
estM = tensor(estM);

for i = 1:3
    A0{i} = max(eps,randn(Nway(i),coreNway(i)));
end

C0 = tensor(max(eps,randn(coreNway)));

%% Solve problem
opts = [];
opts.maxit = 1000; opts.tol = 1e-4;
opts.A0 = A0; opts.C0 = C0;
opts.hosvd = 1;
t0 = tic;
[A1,C1,Out1] = ntdc_apg(data,known,Nway,coreNway,opts);
time = toc(t0);

% Reporting
relerr = norm(full(ttensor(C1,A1))-M)/norm(M);
fprintf('APG: time = %4.2e, ',time);
fprintf('solution relative error = %4.2e\n\n',relerr);

%% Solve problem
opts = [];
opts.maxit = 1000; opts.tol = 1e-4;
opts.A0 = A0; opts.C0 = C0;
opts.hosvd = 1;
t0 = tic;
[A2,C2,Out2] = ntdc_fapg(data,known,Nway,coreNway,opts);
time = toc(t0);

% Reporting
relerr = norm(full(ttensor(C2,A2))-M)/norm(M);
fprintf('Improved APG: time = %4.2e, ',time);
fprintf('solution relative error = %4.2e\n\n',relerr);

%%
fig = figure('Papersize',[5,4],'Paperposition',[0,0,5,4]);
semilogy(Out1.hist_rel(2,:),'r--','linewidth',2)
hold on;
semilogy(Out2.hist_rel(2,:),'k-','linewidth',2)
legend('APG','Improved APG','location','northeast');
xlabel('Iterations','fontsize',12)
ylabel('Relative Error','fontsize',12)