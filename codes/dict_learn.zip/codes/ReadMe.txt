Each testing files start with "test_". 

For example, in the folder "Inpainting", "test_mc.m" is for testing image inpainting.

How to run:

1. Unzip codes.zip to a folder, say, codes 

2. add the folder "codes" in MATLAB dicrectory

3. type "test_mc" for image inpainting test (similar for other testing files) 