Add the folder tensor_toolbox to MATLAB path
Run quicktest.m to test ALSaS and iHOOI

Reference:
Yangyang Xu. On higher-order singular value decomposition from incomplete data.
arXiv preprint. arXiv:1411.4324