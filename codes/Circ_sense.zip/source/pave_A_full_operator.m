%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [A, Dict_Operator] = pave_A_full_operator(p,V,D,Nrm,N1,N2,n1,n2,K)
nr = floor(N1/n1); nc = floor(N2/n2);
resnr = N1-nr*n1; resnc = N2-nc*n2;

A.times = @(x) A_n2m(x,p,V,D,Nrm,N1,N2,n1,n2,K,nr,nc,resnr,resnc);
A.trans = @(y) A_m2n(y,p,V,D,Nrm,N1,N2,n1,n2,K,nr,nc,resnr,resnc);
Dict_Operator  = @(x) A_n2n(x,D,N1,N2,n1,n2,K,nr,nc,resnr,resnc);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = A_n2n(x,D,N1,N2,n1,n2,K,nr,nc,resnr,resnc)
y = zeros(N1,N2);
k = 0;
for j = 1:nc
    for i = 1:nr
        start_row = (i-1)*n1+1; start_col = (j-1)*n2+1;
        end_row = i*n1; end_col = j*n2;
        k = k+1;
        y(start_row:end_row,start_col:end_col) = ...
            reshape(D*x((k-1)*K+1:k*K),n1,n2);
    end
end
if resnr~=0
    for j = 1:nc
        start_row = nr*n1+1;
        start_col = (j-1)*n2+1; end_col = j*n2;
        k = k+1;
        xi = reshape(D*x((k-1)*K+1:k*K),n1,n2);
        y(start_row:end,start_col:end_col) = xi(end-resnr+1:end,:);
    end
end
if resnc~=0
    for i = 1:nr
        start_col = nc*n2+1;
        start_row = (i-1)*n1+1; end_row = i*n1;
        k = k+1;
        xi = reshape(D*x((k-1)*K+1:k*K),n1,n2);
        y(start_row:end_row,start_col:end) = xi(:,end-resnc+1:end);
    end
end
if resnr~=0 && resnc~=0
    k = k+1;
    start_row = nr*n1+1; start_col = nc*n2+1;
    xi = reshape(D*x((k-1)*K+1:k*K),n1,n2);
    y(start_row:end,start_col:end) = xi(end-resnr+1:end,end-resnc+1:end);
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = A_n2m(x,p,V,D,Nrm,N1,N2,n1,n2,K,nr,nc,resnr,resnc)
y = zeros(N1,N2);
k = 0;
for j = 1:nc
    for i = 1:nr
        start_row = (i-1)*n1+1; start_col = (j-1)*n2+1;
        end_row = i*n1; end_col = j*n2;
        k = k+1;
        y(start_row:end_row,start_col:end_col) = ...
            reshape(D*x((k-1)*K+1:k*K),n1,n2);
    end
end
if resnr~=0
    for j = 1:nc
        start_row = nr*n1+1;
        start_col = (j-1)*n2+1; end_col = j*n2;
        k = k+1;
        xi = reshape(D*x((k-1)*K+1:k*K),n1,n2);
        y(start_row:end,start_col:end_col) = xi(end-resnr+1:end,:);
    end
end
if resnc~=0
    for i = 1:nr
        start_col = nc*n2+1;
        start_row = (i-1)*n1+1; end_row = i*n1;
        k = k+1;
        xi = reshape(D*x((k-1)*K+1:k*K),n1,n2);
        y(start_row:end_row,start_col:end) = xi(:,end-resnc+1:end);
    end
end
if resnr~=0 && resnc~=0
    k = k+1;
    start_row = nr*n1+1; start_col = nc*n2+1;
    xi = reshape(D*x((k-1)*K+1:k*K),n1,n2);
    y(start_row:end,start_col:end) = xi(end-resnr+1:end,end-resnc+1:end);
end
y = y./Nrm;
y = fft2(V.*ifft2(y));
y = y(p);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = A_m2n(y,p,V,D,Nrm,N1,N2,n1,n2,K,nr,nc,resnr,resnc)
Z = zeros(N1,N2); Z(p) = y;
Z = fft2(conj(V).*ifft2(Z));
Z = Z./Nrm;
N = nr*nc+sign(resnr)*nc+sign(resnc)*nr+sign(resnr*resnc);
x = zeros(K*N,1);
k = 0;
for j = 1:nc
    for i = 1:nr
        start_row = (i-1)*n1+1; start_col = (j-1)*n2+1;
        end_row = i*n1; end_col = j*n2;
        k = k+1;
        z = Z(start_row:end_row,start_col:end_col);
        x((k-1)*K+1:k*K) = D'*z(:);
    end
end
if resnr~=0
    for j = 1:nc
        start_row = nr*n1+1;
        start_col = (j-1)*n2+1; end_col = j*n2;
        k = k+1;
        z = zeros(n1,n2);
        z(end-resnr+1:end,:) = Z(start_row:end,start_col:end_col);
        x((k-1)*K+1:k*K) = D'*z(:);
    end
end
if resnc~=0
    for i = 1:nr
        start_col = nc*n2+1;
        start_row = (i-1)*n1+1; end_row = i*n1;
        k = k+1;
        z = zeros(n1,n2);
        z(:,end-resnc+1:end) = Z(start_row:end_row,start_col:end);
        x((k-1)*K+1:k*K) = D'*z(:);
    end
end
if resnr~=0 && resnc~=0
    k = k+1;
    start_row = nr*n1+1; start_col = nc*n2+1;
    z = zeros(n1,n2);
    z(end-resnr+1:end,end-resnc+1:end) = Z(start_row:end,start_col:end);
    x((k-1)*K+1:k*K) = D'*z(:);
end