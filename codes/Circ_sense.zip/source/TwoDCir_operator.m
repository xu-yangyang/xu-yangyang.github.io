%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [A,C] = TwoDCir_operator(p,V,D,K)

% Define A*x and A'*y for a partial DWHT matrix A
% Input:
%            n = interger of a power of 2
%        picks = sub-vector of a permutation of 1:n
% Output:
%        A = struct of 2 fields
%            1) A.times: A*x
%            2) A.trans: A'*y
[nr,nc] = size(V); n = nr*nc;
U = fft2(V)/n;
W = zeros(n);
for j = 1:nc
    for i = 1:nr
        k = i+(j-1)*nr;
        W(:,k) = U(:);
        U = circshift(U,[1,0]);
    end
    U = circshift(U,[0,1]);
end
W = W.';
Nrm = zeros(n,1);
for i=1:n
    Nrm(i) = norm(W(p,i));
end
A.times = @(x) Twod_n2m(x,p,V,D,K,Nrm);
A.trans = @(y) Twod_m2n(y,p,V,D,K,Nrm);
C = @(x) TwoDCir(x,p,V,Nrm);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = Twod_n2m(x,p,V,D,K,Nrm)

Y = reshape((D*x)./Nrm,size(V));
Y = ifft2(V.*(fft2(Y)));
y = Y(p);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function x = Twod_m2n(y,p,V,D,K,Nrm)
[nr,nc] = size(V);
n = nr*nc;
X = zeros(nr,nc); X(p) = y;
X = ifft2(conj(V).*(fft2(X)));
x = X(:);
x = D'*(x./Nrm);

function y = TwoDCir(x,p,V,Nrm)
[nr,nc] = size(V);
y = ifft2(V.*(fft2(reshape(x./Nrm,nr,nc))));
y = y(p);