clear; close all;
rand('state',2013); randn('state',2013);

% specify the size of the problem
n = 512; m = 64;

suc = zeros(2,6);

testnum = 50; % total number of independent runs

Psi = dftmtx(n)/sqrt(n); % Fourier basis

for k = 6:3:21 % sparsity level
    for num = 1:testnum
                
        %% generate a sparse signal
        
        xs = zeros(n,1);
        xs(randsample(n,k)) = randn(k,1); % k-sparse signal
        xs = xs/norm(xs); % normalize the signal
        xstart = randn(n,1); % starting point for yall1 
        
        %% generate random circulant matrix
        
        v = randn(1,n)+1i*randn(1,n); % generate random kernel
        C = gallery('circul',v); % generate circulant matrix
        p = randperm(n);
        Phi = C(p(1:m),:); % select m rows at random
        % normalize sensing matrix
        for i=1:n
            Phi(:,i) = Phi(:,i)/norm(Phi(:,i));
        end
        
        % call yall1
        A = Phi*Psi;        b = A*xs;
        opts = [];      opts.tol = 5e-8;        opts.x0 = xstart;         
        x = yall1(A,b,opts);
        
        % record successful recovery of random circulant
        if norm(x-xs)/norm(xs) < 1e-4 
            suc(1,k/3-1) = suc(1,k/3-1)+1; 
        end
        
        %% learn circulant matrix
        
        % form the quadratic program to get the optimized kernel
        % see formula (3.3) in our paper        
        F = dftmtx(n)/sqrt(n); % discreate Fourier matrix
        B = F'*Psi*Psi'*F; Bsq = B.*conj(B); dB = diag(B);
        Bsq = (Bsq+Bsq')/2;
        quadopts = optimset('Algorithm','active-set',...
                'Display','off');
        dsq = quadprog(Bsq,-dB,[],[],[],[],zeros(n,1),[],[],quadopts);
        d = sqrt(dsq).*exp(2*1i*pi*rand(n,1)); % generate phase at random
        C = F*diag(d)*F'; % get the learned circulant
        
        Phi = C(p(1:m),:); % select m rows
        % normalize sensing matrix
        for i=1:n
            Phi(:,i) = Phi(:,i)/norm(Phi(:,i));
        end
        
        % call yall1
        A = Phi*Psi;        b = A*xs;        
        opts = [];      opts.tol = 5e-8;        opts.x0 = xstart;        
        x = yall1(A,b,opts);
        
        % record successful recovery of optimized circulant
        if norm(x-xs)/norm(xs) < 1e-4; 
            suc(2,k/3-1) = suc(2,k/3-1)+1; 
        end;
        
    end
end

%% Reporting
suc = suc/testnum; 
plot(6:3:21,suc(1,:),'r-d','linewidth',2)
hold on;
plot(6:3:21,suc(2,:),'b--+','linewidth',2)
legend('random circulant','optimized circulant','location','best');
xlabel('sparsity level','fontsize',12);
ylabel('success rate','fontsize',12);