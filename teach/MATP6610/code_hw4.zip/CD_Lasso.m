function [x, hist_obj] = CD_Lasso(A,b,x0,lam,maxit)

% coordinate descent for solving the Lasso problem
% min_x 0.5*||A*x-b||^2 + lam*||x||_1

n = length(x0);

% initialization
x = x0;

% set a constant step size
alpha = 1/norm(A*A');

hist_obj = .5*norm(A*x-b)^2 + lam*norm(x,1);

for iter = 1:maxit
    
    % within each iteration, cycle through all coordinates
    for i = 1:n
        % update x(i)
           
    end
    
    % compute the objective value after each iteration
    hist_obj = [hist_obj; .5*norm(A*x-b)^2 + lam*norm(x,1)];
end

end