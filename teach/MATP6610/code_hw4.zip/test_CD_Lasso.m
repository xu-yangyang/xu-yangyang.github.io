clear; close all;
%% generate data
randn('seed',20190315);
rand('seed',20190315);
m = 100;
n = 1000;
s = 10;
A = randn(m,n);
for i = 1:m
    A(i,:) = A(i,:)/norm(A(i,:));
end

xorg = zeros(n,1);
xorg(randsample(n,s)) = randn(s,1);
b = A*xorg;
lam = 1e-3;

x0 = zeros(n,1);

maxit = 200;

%% obtain optimal objective by QP
H = [A'*A, zeros(n); zeros(n,2*n)];
f = [-A'*b; lam*ones(n,1)];
Aineq = [eye(n), -eye(n); -eye(n), -eye(n)];
bineq = zeros(2*n,1);
w = quadprog(H,f,Aineq,bineq);
xopt = w(1:n);
fopt = 0.5*norm(A*xopt-b)^2 + lam*norm(xopt,1);


%% run my code
t0 = tic;
[x_s,hist_obj_s] = CD_Lasso(A,b,x0,lam,maxit);
t1 = toc(t0);

fprintf('Total running time of my code is %5.4f\n', t1);

fig = figure('papersize',[5,4],'paperposition',[0,0,5,4]);

semilogy(hist_obj_s - fopt, 'r-','linewidth',2);

xlabel('Iteration number','fontsize',12);
ylabel('objective error','fontsize',12);

title('My code','fontsize',12);

%% run instructor's code
t0 = tic;
[x_p,hist_obj_p] = CD_Lasso_p(A,b,x0,lam,maxit);
t1 = toc(t0);

fprintf('Total running time of instructor code is %5.4f\n', t1);

fig = figure('papersize',[5,4],'paperposition',[0,0,5,4]);

semilogy(hist_obj_p - fopt, 'b-','linewidth',2);

xlabel('Iteration number','fontsize',12);
ylabel('objective error','fontsize',12);

title('Instructor code','fontsize',12);


