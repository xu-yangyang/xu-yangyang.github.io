function [x, hist_obj] = quadMin_gd(A,b,x0,maxit,lb,ub)

% proximal gradient method for solving
% min_x 0.5*x'*A*x - b'*x
% s.t. lb <= x <= ub

x = x0;

% compute gradient of the objective
grad = ;

% compute the Lipschitz constant of grad
L = norm(A);

hist_obj = .5*(x'* (grad - b));

for iter = 1:maxit
    
    % update x
    x = ;
    
    % compute gradient of the objective
    grad = ;
    
    % save objective value
    hist_obj = [hist_obj; .5*(x'* (grad - b))];
    
end

end

