n = 100;
randn('seed',20190208);
[Q,~] = qr(randn(n));
lam_min = 1;
lam_max = 100;
lam = linspace(lam_min,lam_max,n);

A = Q*diag(lam)*Q';
b = randn(n,1);

x0 = randn(n,1);
lb = -ones(n,1);
ub = ones(n,1);

maxit = 200;

%% compute optimal solution by MATLAB built-in function quadprog
[xopt, fopt] = quadprog(A, -b, [],[],[],[],lb,ub);

%% call your PG method
t0 = tic;
[x_s, hist_obj_s] = quadMin_pg(A,b,x0,maxit,lb,ub);
t1 = toc(t0);

fprintf('Total running time is %5.4f\n', t1);

fprintf('Final objective value is %5.4f\n', .5*x_s'*A*x_s - b'*x_s);

fig = figure('papersize',[5,4],'paperposition',[0,0,5,4]);

semilogy(hist_obj_s - fopt, 'b-','linewidth',2);

xlabel('Iteration number','fontsize',12);
ylabel('objective error','fontsize',12);

%% call your APG method
t0 = tic;
[x_s, hist_obj_s] = quadMin_apg(A,b,x0,maxit,lb,ub);
t1 = toc(t0);

fprintf('Total running time is %5.4f\n', t1);

fprintf('Final objective value is %5.4f\n', .5*x_s'*A*x_s - b'*x_s);

fig = figure('papersize',[5,4],'paperposition',[0,0,5,4]);

semilogy(hist_obj_s - fopt, 'b-','linewidth',2);

xlabel('Iteration number','fontsize',12);
ylabel('objective error','fontsize',12);

%% call instructor's PG method
t0 = tic;
[x_p, hist_obj_p] = quadMin_pg_p(A,b,x0,maxit,lb,ub);
t1 = toc(t0);

fprintf('Total running time is %5.4f\n', t1);

fprintf('Final objective value is %5.4f\n', .5*x_p'*A*x_p - b'*x_p);

fig = figure('papersize',[5,4],'paperposition',[0,0,5,4]);

semilogy(hist_obj_p - fopt, 'b-','linewidth',2);

xlabel('Iteration number','fontsize',12);
ylabel('objective error','fontsize',12);

%% call instructor's APG method
t0 = tic;
[x_p, hist_obj_p] = quadMin_apg_p(A,b,x0,maxit,lb,ub);
t1 = toc(t0);

fprintf('Total running time is %5.4f\n', t1);

fprintf('Final objective value is %5.4f\n', .5*x_p'*A*x_p - b'*x_p);

fig = figure('papersize',[5,4],'paperposition',[0,0,5,4]);

semilogy(hist_obj_p - fopt, 'b-','linewidth',2);

xlabel('Iteration number','fontsize',12);
ylabel('objective error','fontsize',12);